data:extend({
    {
        type = "recipe-category",
        name = "ore-washing-recipes",
        localised_name = "Washing Recipes",
        localised_description = "Recipies used in ore washing facilities"
    }

})
