require("prototypes.item")
require("prototypes.recipe")
require("prototypes.fluid")
require("prototypes.technology")